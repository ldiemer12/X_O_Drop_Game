package com.example.x_odropgame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class GameView extends View {

    private Paint paint;
    private int barX, barY, barWidth, barHeight;

    public GameView(Context context) {
        super(context);
        paint = new Paint();

        barWidth = 200;
        barHeight = 40;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.WHITE);

        barX = canvas.getWidth() / 2 - barWidth / 2;
        paint.setColor(Color.BLACK);

        barY = 1800;
        canvas.drawRect(barX, barY, barX + barWidth, barY + barHeight, paint);
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        barX = (int) event.getX() - barWidth / 2;

        if (barX < 0) barX = 0;
        if (barX + barWidth > getWidth()) {
            barX = getWidth() - barWidth;
        }

        invalidate();
        return true;
    }

}